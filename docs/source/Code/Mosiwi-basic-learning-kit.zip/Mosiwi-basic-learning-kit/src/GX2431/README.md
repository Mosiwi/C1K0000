# GX2431_Arduino
Arduino library for GX2431 1-Wire EEPROM.

Tested on arduino uno r3.

## Required libraries
* OneWire <https://github.com/PaulStoffregen/OneWire>
