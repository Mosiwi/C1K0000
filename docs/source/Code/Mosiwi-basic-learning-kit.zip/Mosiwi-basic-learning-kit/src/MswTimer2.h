/*
 This example works with the Mosiwi Basic learning board.
 
 Web: http://mosiwi.com/
 Wiki: https://mosiwi-wiki.readthedocs.io
 Designer: jalen
 Date：2022-3-17
 */
#ifndef MswTimer2_h
#define MswTimer2_h
#include <Arduino.h>

#include "MsTimer2/MsTimer2.h"


#endif
