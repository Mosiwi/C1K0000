/*
 This example works with the Mosiwi Basic learning board.
 
 Web: http://mosiwi.com/
 Wiki: https://mosiwi-wiki.readthedocs.io
 Designer: jalen
 Date：2022-3-17
 */
#ifndef MswTimer1_h
#define MswTimer1_h
#include <Arduino.h>

#include "TimerOne/TimerOne.h"


#endif
