def hello():
    print("hello!")
    
class prt:
    def __init__(self):
        pass
    def hello(self):
        print("class: hello!")